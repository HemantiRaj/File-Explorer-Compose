package com.raival.compose.file.explorer.screen.main.tab.files.misc

const val ROOT = 0
const val INTERNAL_STORAGE = 1
const val EXTERNAL_STORAGE = 2
const val UNKNOWN = 3