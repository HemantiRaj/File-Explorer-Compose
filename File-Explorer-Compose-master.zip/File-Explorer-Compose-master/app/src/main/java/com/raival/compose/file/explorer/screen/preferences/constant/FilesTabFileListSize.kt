package com.raival.compose.file.explorer.screen.preferences.constant

enum class FilesTabFileListSize {
    SMALL,
    MEDIUM,
    LARGE,
    EXTRA_LARGE
}