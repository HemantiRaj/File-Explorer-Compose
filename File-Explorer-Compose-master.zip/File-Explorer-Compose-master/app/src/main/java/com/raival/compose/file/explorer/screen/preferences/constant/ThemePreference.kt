package com.raival.compose.file.explorer.screen.preferences.constant

enum class ThemePreference {
    LIGHT,
    DARK,
    SYSTEM
}