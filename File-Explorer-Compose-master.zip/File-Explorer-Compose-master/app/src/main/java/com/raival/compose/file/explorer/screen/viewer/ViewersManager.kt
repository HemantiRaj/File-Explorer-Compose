package com.raival.compose.file.explorer.screen.viewer

class ViewersManager {
    val instances = mutableListOf<ViewerInstance>()
}