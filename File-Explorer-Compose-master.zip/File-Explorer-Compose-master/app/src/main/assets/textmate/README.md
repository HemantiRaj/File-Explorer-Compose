Thanks to: [CodeAssist](https://github.com/tyron12233/CodeAssist)
Original source: https://github.com/tyron12233/CodeAssist/tree/main/app/src/main/assets/textmate